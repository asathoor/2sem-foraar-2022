console.log("hej fra vikinger.js")

const token = "pk.eyJ1IjoiYXNhdGhvb3IiLCJhIjoiY2oyd3hlbzU3MDA5NzJxbm9iMjczanJndCJ9.HahDB7Z1rrD5THIYQh6t4g"
const mapStyle = "mapbox://styles/asathoor/cl0utivlp00jl14qi4gto0iyl"
const vikinger = "js/vikinger.geojson"

// Concerning the Map
mapboxgl.accessToken = token
const map = new mapboxgl.Map({
  container: 'map', // container ID
  style: mapStyle, // style URL
  center: [-50, 56.32], // starting position [lng, lat]
  zoom: 2.3, // starting zoom
  pitch: 60,
  customAttribution: '&copy; Grevinde Danner'
});

// begynd fetch() her
fetch(vikinger).then(
  response => {
    return response.json(); // get JSON data$
  }).then(data => {

  console.log(data);
  // tjek objektet i browserens udviklingsværktøj


}).catch(err => {
  // Error and description
  console.log('Error: ' + err)
})
