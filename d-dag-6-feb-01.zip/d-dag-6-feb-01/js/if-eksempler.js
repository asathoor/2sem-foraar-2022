/* file: if-eksempler.js */
console.log('hej fra if eksempler');

// bilen kører med
let hastighed = 30;

// kører vi for stærkt?

if ( hastighed < 45 ) {
  resultat.innerHTML = "Do kører for langsomt!"
}
/*
if ( hastighed <= 60 ) {
  resultat.innerHTML = "Du kører med en passende hastighed"
}

else {
  resultat.innerHTML = "Do kører for hurtigt!"
}
*/
